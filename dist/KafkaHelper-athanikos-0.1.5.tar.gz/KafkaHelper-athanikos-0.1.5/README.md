### Kafka Helper 
A set of methods to produce / consume to kafka 

#### kafka install / run 
https://kafka.apache.org/quickstart

#### to package 


#### to run tests 
cd <kakfadir>/bin 
./zookeeper-server-start.sh ../config/zookeeper.properties
./kafka-server-start.sh ../config/server.properties
sudo service mongod restart 
